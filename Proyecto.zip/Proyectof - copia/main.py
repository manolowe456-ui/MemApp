import kivy
from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.button import Button
from kivy.properties import StringProperty, NumericProperty, BooleanProperty, ObjectProperty
from kivy.clock import Clock
from kivy.lang import Builder
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.core.window import Window
import random
import time
import os

class Carta(Button):
    valor = StringProperty('')
    volteada = BooleanProperty(False)
    imagen_frente = StringProperty('')
    imagen_reverso = StringProperty('')

    # No hacemos Window.bind en cada instancia; mantenemos tamaños iniciales
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # directorio de assets relativo al archivo
        def asset(name):
            return os.path.join(os.path.dirname(__file__), 'assets', name)

        # valores por defecto (si no existen archivos, se usan cadenas vacías)
        try:
            self.imagen_reverso = asset('reverso.png') if os.path.exists(asset('reverso.png')) else ''
        except Exception:
            self.imagen_reverso = ''

        # imagen_frente se calculará cuando el property 'valor' esté listo (on_kv_post)
        self.size_hint = (None, None)
        width = min(Window.width / 6, Window.height / 6)
        self.size = (width, width)

    def on_kv_post(self, base_widget):
        # Después de cargar en KV, definimos la ruta frontal con el valor actual
        def asset(name):
            return os.path.join(os.path.dirname(__file__), 'assets', name)

        if self.valor:
            posible = asset(f"{self.valor}.png")
            self.imagen_frente = posible if os.path.exists(posible) else ''

        # ajustamos las imágenes de fondo según si están disponibles
        if self.volteada:
            if self.imagen_frente:
                self.background_normal = self.imagen_frente
                self.background_down = self.imagen_frente
        else:
            if self.imagen_reverso:
                self.background_normal = self.imagen_reverso
                self.background_down = self.imagen_reverso

    def actualizar_tamanio(self, instance, value):
        width = min(Window.width/6, Window.height/6)
        self.size = (width, width)

    def on_volteada(self, instance, value):
        if value:
            self.background_normal = self.imagen_frente
            self.background_down = self.imagen_frente
        else:
            self.background_normal = self.imagen_reverso
            self.background_down = self.imagen_reverso


class PantallaInicioGrid(Screen):
    pass

class PantallaRegistroGrid(Screen):
    sexo_seleccionado = StringProperty('niño')
    
    def mostrar_error(self, mensaje):
        popup = Popup(title='Error',
                     content=Label(text=mensaje),
                     size_hint=(None, None), size=(400, 200))
        popup.open()
    
    def validar_datos(self):
        nombre = self.ids.nombre_input.text.strip()
        edad = self.ids.edad_input.text.strip()
        
        if not nombre:
            self.mostrar_error('Por favor ingresa tu nombre')
            return
            
        if not edad:
            self.mostrar_error('Por favor ingresa tu edad')
            return
            
        try:
            edad_num = int(edad)
            if edad_num <= 0 or edad_num > 120:
                self.mostrar_error('Por favor ingresa una edad válida')
                return
        except ValueError:
            self.mostrar_error('La edad debe ser un número')
            return
            
        self.manager.current = 'pantalla_cartas'

class PantallaCartasGrid(Screen):
    tiempo_str = StringProperty("00:00")
    errores = NumericProperty(0)
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.tiempo_segundos = 0
        self.cronometro = None
        self.cartas_volteadas = []
        self.pares_encontrados = 0
        self.puede_voltear = True
    
    def on_pre_enter(self, *args):
        self.iniciar_juego()

    def iniciar_juego(self):
        self.ids.grid_cartas.clear_widgets()
        self.reiniciar_variables()
        
        valores_cartas = ['A', 'E', 'I', 'O', 'U', 'A', 'E', 'I', 'O', 'U']
        random.shuffle(valores_cartas)
        
        for valor in valores_cartas:
            carta = Carta(valor=valor)
            carta.bind(on_press=self.voltear_carta)
            self.ids.grid_cartas.add_widget(carta)
            
        self.cronometro = Clock.schedule_interval(self.actualizar_tiempo, 1) 

    def reiniciar_variables(self):
        self.tiempo_segundos = 0
        self.errores = 0
        self.tiempo_str = "00:00"
        self.cartas_volteadas = []
        self.pares_encontrados = 0
        if self.cronometro:
            self.cronometro.cancel()
            self.cronometro = None

    def actualizar_tiempo(self, dt):
        self.tiempo_segundos += 1
        minutos = self.tiempo_segundos // 60
        segundos = self.tiempo_segundos % 60
        self.tiempo_str = f"{minutos:02}:{segundos:02}" 

    def voltear_carta(self, carta_presionada):
        
        if carta_presionada.volteada or len(self.cartas_volteadas) == 2:
            return
            
        carta_presionada.volteada = True 
        self.cartas_volteadas.append(carta_presionada)
        
        if len(self.cartas_volteadas) == 2:
            Clock.schedule_once(self.checar_par, 0.8) 

    def checar_par(self, dt):
        carta1, carta2 = self.cartas_volteadas
        
        if carta1.valor == carta2.valor:
            self.pares_encontrados += 1
          
            carta1.disabled = True 
            carta2.disabled = True
            if self.pares_encontrados == 5: 
                self.fin_juego()
        else:
            self.errores += 1
            carta1.volteada = False 
            carta2.volteada = False
            
        self.cartas_volteadas = []
    def fin_juego(self):
        if self.cronometro:
            self.cronometro.cancel()
            self.cronometro = None
            
        pantalla_final = self.manager.get_screen('pantalla_Final')
        pantalla_final.tiempo_final = self.tiempo_str
        pantalla_final.errores_final = self.errores
        
        self.manager.current = "pantalla_Final"
    def on_leave(self, *args):
        self.reiniciar_variables()
        self.ids.grid_cartas.clear_widgets()

class PantallaFinalGrid(Screen):
    tiempo_final = StringProperty("00:00")
    errores_final = NumericProperty(0)
    
    def reiniciar_juego(self):
        pantalla_cartas = self.manager.get_screen('pantalla_cartas')
        pantalla_cartas.iniciar_juego()
        self.manager.current = 'pantalla_cartas'
        
    def on_pre_enter(self, *args):
        pantalla_cartas = self.manager.get_screen('pantalla_cartas')
        self.tiempo_final = pantalla_cartas.tiempo_str
        self.errores_final = pantalla_cartas.errores

class MemoramaApp(App):
    def build(self):
        # Intentamos cargar el archivo KV; si falla, devolvemos un ScreenManager básico
        try:
            return Builder.load_file('memorama.kv')
        except Exception as e:
            print('Error cargando memorama.kv:', e)
            # Construcción mínima para evitar crash y poder testear la lógica
            sm = ScreenManager()
            sm.add_widget(PantallaInicioGrid(name='pantalla_inicio'))
            sm.add_widget(PantallaRegistroGrid(name='pantalla_registro'))
            sm.add_widget(PantallaCartasGrid(name='pantalla_cartas'))
            sm.add_widget(PantallaFinalGrid(name='pantalla_Final'))
            return sm


if __name__ == "__main__":
    MemoramaApp().run()